import React from 'react';
import type { Contact, GroupEditState, InboxItem, Message, MessagingView, WsStatus } from '../types/messaging';
interface MessagingContextValue {
    isSessionActive: boolean;
    isReady: boolean;
    initError: string | null;
    /** Last attachment upload/send failure (cleared on next attempt). */
    attachmentError: string | null;
    contact: Contact | null;
    panelOpen: boolean;
    panelHeightRatio: number;
    activeView: MessagingView;
    inbox: InboxItem[];
    messages: Message[];
    visibleContacts: Contact[];
    activeConversationId: string | null;
    activeConversationName: string | null;
    activeIsGroup: boolean;
    groupEdit: GroupEditState | null;
    totalUnread: number;
    loadingMessages: boolean;
    wsStatus: WsStatus;
    openPanel: () => void;
    closePanel: () => void;
    togglePanel: () => void;
    setPanelHeightRatio: (ratio: number) => void;
    setView: (view: MessagingView) => void;
    openConversation: (item: InboxItem) => void;
    openDirectConversation: (recipient: Contact) => void;
    openCreateGroup: () => void;
    openGroupSettings: () => void;
    clearGroupEdit: () => void;
    goBackToInbox: () => void;
    loadOlderMessages: () => Promise<void>;
    sendChatMessage: (content: string) => Promise<void>;
    sendChatImage: (uri: string, fileName: string) => Promise<void>;
    toggleReaction: (messageId: string, emoji: string) => Promise<void>;
    refreshInbox: () => Promise<void>;
    createGroup: (participantIds: string[], name: string) => Promise<void>;
    saveGroupEdit: (name: string, addIds: string[], removeIds: string[]) => Promise<void>;
    deleteGroup: () => Promise<void>;
    clearConversation: (item: InboxItem) => Promise<void>;
    deleteConversationItem: (item: InboxItem) => Promise<void>;
    openMessageSearch: () => void;
    searchMessages: (query: string) => Promise<Message[]>;
    threadParent: Message | null;
    threadMessages: Message[];
    openThread: (message: Message) => Promise<void>;
    closeThread: () => void;
    sendThreadMessage: (content: string) => Promise<void>;
    editChatMessage: (messageId: string, content: string) => Promise<void>;
    deleteChatMessage: (messageId: string) => Promise<void>;
    togglePinMessage: (message: Message) => Promise<void>;
    sendChatAttachments: (files: {
        uri: string;
        fileName: string;
    }[], caption?: string) => Promise<void>;
    favoriteConversationIds: ReadonlySet<string>;
    isFavoriteConversation: (conversationId: string) => boolean;
    toggleFavoriteConversation: (conversationId: string) => Promise<void>;
    /** `screen` = dedicated tab; `overlay` = bottom sheet (default). */
    presentation: 'overlay' | 'screen';
}
export type MessagingPresentation = 'overlay' | 'screen';
export declare function MessagingProvider({ children, sessionGid, userEmail, presentation, }: {
    children: React.ReactNode;
    sessionGid: string | null;
    userEmail: string | null;
    presentation?: MessagingPresentation;
}): import("react/jsx-runtime").JSX.Element;
export declare function useMessaging(): MessagingContextValue;
export declare function useMessagingOptional(): MessagingContextValue | null;
export declare function requestMessagingOpen(): void;
export {};
//# sourceMappingURL=MessagingContext.d.ts.map